/*
 * Planes revision exercise (14 November, Friday Week 1)
 *
 * A plane is controlled by four numbers: left axis, right axis, left engine, right engine.
 * The left axis/engine are determined by user input. The right axis/engine are randomly generated
 * numbers from 1 to 6.
 *
 * The rotation of the plane is the difference between the left and right axes.
 *
 * The speed of the plane depends on the sum of the left and right engines:
 * - if the sum is between 1 and 4, the speed is 0
 * - if the sum is between 5 and 8, the speed is 1
 * - if the sum is between 9 and 12, the speed is 2
 *
 * This program creates two plane objects and prints information about the planes.
 */

public class PlaneController {

    public void start() {
        Plane plane1 = new Plane();
        Plane plane2 = new Plane();
        plane1.printPlaneInformation();
        System.out.println();
        plane2.printPlaneInformation();
    }

    public void printPlaneInformation() {
        Plane plane = new Plane();
        System.out.println("Left axis: " + plane.getLeftAxis());
        System.out.println("Right axis: " + plane.getRightAxis());
        System.out.println("Left engine: " + plane.getLeftEngine());
        System.out.println("Right engine: " + plane.getRightEngine());
        System.out.println();
        System.out.println("The plane's rotation is " + plane.getRotation());
        System.out.println("The plane's speed is " + plane.getSpeed());
    }

    public static void main(String[] args) {
        PlaneController p = new PlaneController();
        p.start();
    }

}
