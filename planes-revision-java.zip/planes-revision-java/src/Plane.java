public class Plane {

    private int leftAxis;
    private int rightAxis;
    private int leftEngine;
    private int rightEngine;

    public Plane() {
        System.out.print("enter left axis: ");
        this.leftAxis = Integer.parseInt(Keyboard.readInput());
        this.rightAxis = (int) (Math.random() * 6) + 1;

        System.out.print("enter left engine: ");
        this.leftEngine = Integer.parseInt(Keyboard.readInput());
        this.rightEngine = (int) (Math.random() * 6) + 1;
    }

    public int getLeftAxis() {
        return leftAxis;
    }

    public int getRightAxis() {
        return rightAxis;
    }

    public int getLeftEngine() {
        return leftEngine;
    }

    public int getRightEngine() {
        return rightEngine;
    }

    public int getRotation() {
        return rightAxis - leftAxis;
    }

    public int getSpeed() {
        int sumOfEngines = leftEngine + rightEngine;
        return (sumOfEngines - 1) / 4;
    }

    public void printPlaneInformation() {
        System.out.println("Left axis: " + this.getLeftAxis());
        System.out.println("Right axis: " + this.getRightAxis());
        System.out.println("Left engine: " + this.getLeftEngine());
        System.out.println("Right engine: " + this.getRightEngine());
        System.out.println();
        System.out.println("The plane's rotation is " + this.getRotation());
        System.out.println("The plane's speed is " + this.getSpeed());
    }

}
