package ictgradschool.industry.controlflow.coderunner;

/**
 * Please run the TestCodeRunner class to check your answers.
 * There are five exercises in this class. They are ordered roughly in increasing order of difficulty.
 * You can do them in any order you like.
 * <p>
 * You may modify the code in between the comments: // Answer here // . Do not modify other parts of the code.
 * <p>
 */
public class CodeRunner {
    /**
     * Q1. Complete the method getThreeLettersInCapital that takes two parameters: a string for text and an integer for
     * index. The method returns the first three letters of the String in CAPITAL after the index (inclusive of the index).
     * <p>
     * For example, given "hello" and 2, the method should return "LLO".
     * If the index exceeds the length of the given text, you should return an empty string "".
     * If the string does not have three more letters after the index, you should return all letters in CAPITAL
     * after the index.
     */
    public String getThreeLettersInCapital(String text, int index) {
        // Answer here
        if (text.length() < index) {
            return "";
        } else if (text.length() < index + 3) {
            return text.substring(index).toUpperCase();
        }
        return text.substring(index, index + 3).toUpperCase();
        //
    }

    /**
     * Q2. Complete the method EnoughToBuyDrinks that takes three integer parameter representing the number of dollar
     * coins (1), fifty-cent coins (0.5) and ten-cent coins (0.1).
     * The method returns a boolean value: true if the total amount is enough to buy a pint of beer (9.8 dollars),
     * otherwise false.
     */
    public boolean EnoughToBuyDrinks(int dollarCoins, int fiftyCentCoins, int tenCentCoins) {
        double beerPrice = 9.8;
        // Answer here
        double totalAmount = dollarCoins + fiftyCentCoins * 0.5 + tenCentCoins * 0.1;
        return totalAmount >= beerPrice;
        //
    }

    /**
     * Q3. Complete the method called implies that takes two boolean parameters a and b,
     * and returns the result of the boolean expression a => b. That is, if a is true and b is true, the result is true.
     * If a is false, the result is true. Otherwise, the result is false.
     */
    public boolean implies(boolean a, boolean b) {
        // Answer here
        return (a && b) || !a;
        //
    }

    /**
     * Q4. Complete the method checkErrorInRange that takes three double values, a, b, delta.
     * The method returns true if a and b are the same within a given error range indicated by delta.
     * Otherwise, the method returns false if a and b are not the same.
     */
    public boolean checkErrorInRange(double a, double b, double delta) {
        //Answer here
        return Math.abs(a - b) < delta;
        //
    }

    /**
     * Q5. Complete the method generateUsername that takes in as input a full name in the format of "firstName lastName"
     * and returns a String representing a username. The username comprises the first letter of the first name,
     * the first three letters of the last name, and three digits. The three digits are calculated based on the
     * sum of the decimal values of the four letters of the username.
     * <p>
     * For example, given the full name "Taylor Swift", the username would be tswi455.
     * The three digits are calculated based on:
     * The character 't' has the decimal value of 116, the character 's' has the decimal value of 115,
     * the character 'w' has the decimal value of 119, and the character 'i' has the decimal value of 105.
     * Therefore, the three digits are 116 + 115 + 119 + 105 = 455.
     * <p>
     * Note that the username is all in lowercase. You may assume that the given name has no middle name and
     * the last name always has more than three letters.
     * <p>
     * Hint: Consider saving each letter as a char.
     */
    public String generateUsername(String fullName) {
        //Answer here
        String fullNameInLowerCase = fullName.toLowerCase();
        char firstLetter = fullNameInLowerCase.charAt(0);
        int index = fullName.indexOf(" ");
        char secondLetter = fullNameInLowerCase.charAt(index + 1);
        char thirdLetter = fullNameInLowerCase.charAt(index + 2);
        char fourthLetter = fullNameInLowerCase.charAt(index + 3);
        int digits = firstLetter + secondLetter + thirdLetter + fourthLetter;
        String username = "" + firstLetter + secondLetter + thirdLetter + fourthLetter + digits;
        return username;
        //
    }
}
