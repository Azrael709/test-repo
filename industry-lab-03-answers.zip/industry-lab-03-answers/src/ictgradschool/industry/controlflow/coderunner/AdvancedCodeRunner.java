package ictgradschool.industry.controlflow.coderunner;

/**
 * Please run the TestAdvancedCodeRunner class to check your answers.
 * There are five exercises in this class. You can do them in any order you like.
 * <p>
 * You may modify the code in between the comments: // Answer here // . Do not modify other parts of the code.
 * <p>
 */
public class AdvancedCodeRunner {

    /**
     * Q1. Complete the method countDigits that has an integer parameter, and returns the number of digits the value of
     * the parameter has. For negative values, only count the digits, not the negative sign.
     */
    public int countDigits(int number) {
        // Answer here
        number = Math.abs(number);
        return String.valueOf(number).length();
        //
    }

    /**
     * Q2. Complete the method convertIntToColTitle that converts an integer to an excel column letter.
     * For example, column 0 is "A", column 1 is "B", column 26 is "AA".
     * If the given integer is less than 0, then the method should return "Input is invalid".
     */
    public String convertIntToColTitle(int column) {
        // Answer here
        if (column < 0) {
            return "Input is invalid";
        } else if (column == 0) {
            return "A";
        }
        String columnName = "";

        while (column > -1) {
            char colCharacter = (char) ('A' + column % 26);
            columnName = colCharacter + columnName;
            column = column / 26 - 1;
        }

        return columnName;
        //
    }

    /**
     * Q3. Complete the method isIntPalindrome that takes an integer parameter, and returns a boolean value: true if
     * the digits of the given integer are palindromic (i.e. reads the same backwards as forwards). Any leading negative
     * signs should be ignored for the purposes of this exercise.
     */
    public boolean isIntPalindrome(int number) {
        // Answer here
        int tempNum = number;
        int reverseNum = 0;

        while (tempNum != 0) {
            int remainder = tempNum % 10;
            reverseNum = reverseNum * 10 + remainder;
            tempNum = tempNum / 10;
        }
        return number == reverseNum;
        //
    }

    /**
     * Q4. Complete the method printPrimeNumbers that takes an integer parameter and returns a String containing
     * a space separated list of all of the prime numbers starting at 2 and all the way up to and including the given integer.
     * If the given number is negative or no prime numbers are found, return "No prime number found".
     * <p>
     * Note that there is no extra space at the end of the String returned.
     */
    public String printPrimeNumbers(int num) {
        // Answer here
        if (num < 0) {
            return "No prime number found";
        }
        String primeNums = "";
        for (int i = 0; i <= num; i++) {
            if (isPrime(i)) {
                primeNums += i + " ";
            }
        }
        if (primeNums.isEmpty()) {
            return "No prime number found";
        }
        return primeNums.trim();
        //
    }

    private boolean isPrime(int num) {
        // Answer here
        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
        //
    }


    /**
     * Q5. Complete the method simpleMultiplicationTable that takes an integer parameter, and returns a String showing
     * the multiplication table (rows and columns) starting at 1 and up to and including that number.
     * Any 'cell' in the table should display the result of multiplying that row number by that column number.
     * For example, the method would return the following String for an integer parameter of 2:
     * 1 2
     * 2 4
     * For an integer parameter of 3, the method would result in a 3x3 table:
     * 1 2 3
     * 2 4 6
     * 3 6 9
     * Hint: Remember that you can nest loops too. To print new line, use "\n".
     * You may assume that the given integer is always larger than 0.
     */
    public String simpleMultiplicationTable(int num) {
        // Answer here
        String table = "";
        if (num == 1) {
            return "1";
        }
        for (int i = 1; i <= num; i++) {
            for (int j = 1; j <= num; j++) {
                table += i * j + " ";
            }
            table = table.trim() + "\n";
        }
        return table.trim();
        //
    }
}
