package ictgradschool.industry.controlflow.rockpaperscissors;

import ictgradschool.Keyboard;

/**
 * A game of Rock, Paper Scissors
 */
public class RockPaperScissors {

    public static final int ROCK = 1;
    public static final int PAPER = 2;
    public static final int SCISSORS = 3;
    public static final int QUIT = 4;
    // TODO Make similar constants for PAPER and SCISSORS, to improve readability of your code.

    public void start() {

        // TODO Write your code here which calls your other methods in order to play the game. Implement this
        // as detailed in the exercise sheet.

        System.out.print("Hi! What is your name? ");
        String playerName = Keyboard.readInput();

        while (true) {
            printMenu();
            System.out.print("Enter your choice: ");
            int userChoice = Integer.parseInt(Keyboard.readInput());

            if (userChoice == QUIT) {
                break;
            } else if (userChoice < 1 || userChoice > 4) {
                // If the choice is not valid, then start the loop again
                continue;
            }

            System.out.println();

            displayPlayerChoice(playerName, userChoice);

            int computerChoice = getComputerChoice();
            displayPlayerChoice("The computer", computerChoice);

            String winningMsg = "";

            if (userChoice == computerChoice) {
                winningMsg = "No one wins because" + getResultString(userChoice, computerChoice);
            } else if (userWins(userChoice, computerChoice)) {
                winningMsg = playerName + " wins because " + getResultString(userChoice, computerChoice);
            } else {
                winningMsg = "The computer wins because " + getResultString(computerChoice, userChoice);
            }
            System.out.println(winningMsg);
            System.out.println();
        }
        System.out.println();
        System.out.println("Goodbye " + playerName + ". Thanks for playing :)");
    }

    private void printMenu() {
        System.out.println(ROCK + ". Rock");
        System.out.println(PAPER + ". Paper");
        System.out.println(SCISSORS + ". Scissors");
        System.out.println(QUIT + ". Quit");
    }

    private int getComputerChoice() {
        return (int) (Math.random() * 3) + 1;
    }

    public void displayPlayerChoice(String name, int choice) {
        // TODO This method should print out a message stating that someone chose a particular thing (rock, paper or scissors)
        System.out.println(name + " chose " + choiceToString(choice));
    }

    private String choiceToString(int choice) {
        switch (choice) {
            case ROCK:
                return "Rock";
            case PAPER:
                return "Paper";
            case SCISSORS:
                return "Scissors";
            case QUIT:
                return "Quit";
            default:
                return "UNKNOWN";
        }
    }

    public boolean userWins(int playerChoice, int computerChoice) {
        // TODO Determine who wins and return true if the player won, false otherwise.
        if (playerChoice == ROCK) {
            return computerChoice == SCISSORS;
        } else if (playerChoice == PAPER) {
            return computerChoice == ROCK;
        } else if (playerChoice == SCISSORS) {
            return computerChoice == PAPER;
        }
        return false;
    }

    public String getResultString(int playerChoice, int computerChoice) {

        final String PAPER_WINS = "paper covers rock";
        final String ROCK_WINS = "rock smashes scissors";
        final String SCISSORS_WINS = "scissors cut paper";
        final String TIE = " you chose the same as the computer";

        // TODO Return one of the above messages depending on what playerChoice and computerChoice are.
        if (playerChoice == computerChoice) {
            return TIE;
        }
        if (userWins(playerChoice, computerChoice)) {
            if (playerChoice == PAPER) {
                return PAPER_WINS;
            } else if (playerChoice == ROCK) {
                return ROCK_WINS;
            } else if (playerChoice == SCISSORS) {
                return SCISSORS_WINS;
            }
        }
        return null;
    }

    /**
     * Program entry point. Do not edit.
     */
    public static void main(String[] args) {

        RockPaperScissors ex = new RockPaperScissors();
        ex.start();

    }
}
