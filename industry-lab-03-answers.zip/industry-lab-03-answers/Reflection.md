# Reflection of the Lab
*Write your reflective paragraph here and commit by the end of the day.*
