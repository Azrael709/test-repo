# Control Flow

## Overview
This is the source code and instructions for the Control Flow lab. Please read the instructions carefully.

### Examples

In the [examples](./src/ictgradschool/industry/controlflow/examples) package, you'll find some example code to reinforce content taught in lectures. If you're struggling, we suggest you revise the lecture content, take a look at these examples, modify them and see what happens to test your understanding.

## Exercise One: if statements on Paper

Do the following **on paper!**

1. Write a Java if statement that prints out `Healthy weight` if the value of the variable, `bmi`, is between 19 and 25 (inclusive).
2. Write a line of Java code which declares a `boolean` variable named `hasFinished` with an initial value of false. Then, write some Java code which calls the `printResults()` method if the `boolean` variable `hasFinished` is true. You may assume that the `printResults()` method has been implemented elsewhere. 

## Exercise Two: Boolean expressions on Paper

Do the following **on paper!**

1. Write a boolean expression which tests whether the value of the `char` variable, `userResponse`, is equal to either 'y' or 'Y'.
2. Write a boolean expression which tests whether the value of the `int` variable, `amount`, is odd (i.e. not evenly divisible by 2).
3. Write a boolean expression which tests whether the `String` variable, `firstName`, begins with the letter 'A' or 'a'.
4. Write a boolean expression which tests whether the `String` variable, `singer`, is equal to "Taylor Swift".  (Hint: remember that `Strings` are objects, not primitive types.)
6. Write a boolean expression which tests whether the value of the `int` variable `yearBorn`, is greater than 1978 but is not equal to 2013.  

## Exercise Three: if … else if statements on Paper

Do the following **on paper!**

Complete the `getGender()` method below so that it assigns the correct value to the gender variable according to the `code` parameter passed in as a `char`.

The gender will be determined as follows:

- If `code` is equal to 'F' or 'f' the method should assign "Female" to gender
- else if the `code` is equal to 'M'  or 'm', then the method should assign "Male" to gender
- else the method should assign "Unknown" to the `gender` variable. 

```java
private String getGender (char code) { 
    String gender; 
    // TODO write your code here 
 
    return gender; 
} 
```
## Exercise Four: while loops on Paper

Do the following **on paper!**

What is the output produced by the following code snippet?

```java
int number = 5;
while (number < 15) {
    System.out.println(3 * number + " ");
    number += 4;
}
System.out.println();
System.out.println("Number is now: " + number);
```

## Exercise Five: for loops on Paper

Do the following **on paper!**

Using a for loop, complete the `printRowOfAmpersands()` method so that it prints a row of ampersands (`&`).  The number of ampersands it should print is passed via the `int` parameter, `howMany`.

For example, when called by: `printRowAmpersands(5);`
The method prints: `&&&&&`

```java
private void printRowOfAmpersands (int howMany) {
// TODO write your code here

    System.out.println(); 
} 
```

## Exercise Six: Converting a while loop into a for loop on Paper

Do the following **on paper!**

Translate the following while loop into a for loop. 

```java
int i = 0; 
while (i < 7) { 
    System.out.print(2 * i + 3); 
    i++; 
} 
```
## Exercise Seven: CodeRunner Exercises

Complete the methods in `ictgradschool.industry.controlflow.coderunner.CodeRunner.java` using the concepts learned in the first three modules. The instructions are outlined in the class. You can test your answers by running the unit tests supplied in the test folder.

## Exercise Eight: Grade Calculator

Using the skeleton code found in the [GradeCalculator](./src/ictgradschool/industry/controlflow/gradecalculator/GradeCalculator.java) class, complete the following steps:

### Step 1)

Use conditional statements (`if` / `else if` or `switch`) within the `getLetterGrade()` method to get determine the letter grade based on the percentage that the user inputs.

You can choose how you structure your conditional control flow but make sure that it meets the requirements:

- 85% - 100% = A
- 70% - 84% = B
- 50% - 69% = C
- 0% - 49% = D

Make sure to edit the code within the `getLetterGrade()` method so that it returns the required character.

### Step 2)

Notice that currently the code will allow the user to input any number and the user could enter a number that is much larger than 100 or smaller than 0.

Modify the code within `getPercentageScore()` so that if the user enters a number less than 0 or greater than 100 the prompt repeats itself and asks the user to enter the number again. You should use some sort of loop for this.

For now, you can assume that the user will always enter an integer (even if that integer is too large or too small). Later in the course, we'll learn how to properly handle further error cases, such as if the user enters text rather than a number.

## Exercise Nine: Guessing Game using a while loop

In the [GuessingGame](./src/ictgradschool/industry/controlflow/guessing/GuessingGame.java) class, write a program so that the user can play the game of guessing a number between 1 and 100. Use the following pseudocode to write the code:

- Generate a random number between 1 and 100 and store in a variable named `goal`
- Declare a variable named `guess`
- Initialise `guess` to 0
- While the user’s guess is not correct (_i.e._ `while guess != goal`):
    - Ask the user to enter their guess
    - Store the guess in the `guess` variable
    - If the `guess` is greater than the `goal`, print “Too high, try again”
    - Else if the `guess` is less than the `goal`, print “Too low, try again”
    - Else print the message “Perfect!!”
- Print “Goodbye”

Here is an example of the output of the game:

```
Enter your guess (1 – 100): 50
Too low, try again
Enter your guess (1 – 100): 75
Too high, try again
Enter your guess (1 – 100): 70
Perfect!
Goodbye
```

For now, you can assume that the user will always enter an integer. Later in the course, we'll learn how to properly handle further error cases, such as if the user enters text rather than a number.

## Exercise Ten: The game of rock, paper and scissors

For this exercise, complete the code in the [RockPaperScissors](./src/ictgradschool/industry/controlflow/rockpaperscissors/RockPaperScissors.java) class to allow the user to play the game, "Rock Paper Scissors". This game is played as follows:

- In each round the player choose either Rock, Paper or Scissors, and the computer randomly chooses either Rock, Paper or Scissors.
- The winner of that round depends on the items chosen by the computer and the player.
  - If the same item is chosen, the result is a tie. 
  - If the two chosen items are rock and scissors, then the rock wins, because a rock smashes scissors.
  - If scissors and paper are chosen, the scissors win, because scissors cut paper.
  - If paper and rock are chosen, the paper wins, because paper covers rock.

Here is an example of the output of the application:

```text
Hi! What is your name? Yu-Cheng

1. Rock
2. Scissors
3. Paper
4. Quit
Enter choice: 1

Yu-Cheng chose rock.
Computer chose scissors.
Yu-Cheng wins because rock smashes scissors.

1. Rock
2. Scissors
3. Paper
4. Quit
Enter choice: 2

Yu-Cheng chose scissors.
Computer chose scissors.
No one wins.

1. Rock
2. Scissors
3. Paper
4. Quit
Enter choice: 3

Yu-Cheng chose paper.
Computer chose scissors.
The computer wins because scissors cut paper.

1. Rock
2. Scissors
3. Paper
4. Quit
Enter choice: 4

Goodbye Yu-Cheng. Thanks for playing :)
```

When testing the user choice or the computer choice, you must use the symbolic constants that have been declared at the top of the program. E.g.
`public static final int ROCK = 1;`

You will need to implement the following methods:

1. **displayPlayerChoice() method**

   The `displayPlayerChoice()` method has one String parameter and one int parameter. Complete the method so that it prints one line of output. The first part of the output is obtained from the String parameter. The second part depends on the second int parameter (which you should compare with the global constants). Depending on what value the user has entered, the second part of the output will be either: `" chose scissors"`, `" chose rock"`, or `" chose paper"`.

2. **userWins() method**

   The `userWins()` method has two int parameters and returns a boolean. The first int parameter is the user’s choice and the second int parameter is the computer’s choice. The method returns true if the user choice beats the computer choice, otherwise the method returns false.

3. **getResultString() method**

   The `getResultString()` method has two int parameters and returns a String. There are four possible Strings which can be returned by this method:

   ```java
   final String PAPER_WINS = "paper covers rock";
   final String ROCK_WINS = "rock smashes scissors";
   final String SCISSORS_WINS = "scissors cut paper";
   final String TIE = " you chose the same as the computer";
   ```

   The String which is returned depends on the values of the two int parameters. If the two parameter values are equal then the method returns `TIE`.

4. **start() method**

   The `start()` method calls the previous methods for running the application. You will also need to implement the following to complete the application:

  * Printing the prompt and reading the input from the user for the name
  * Printing the prompt and reading the input from the user for the choice of rock, scissors, paper, or quit
  * While the user is playing, display the player choice, determine who wins, and display the results
  * Printing a message to display the goodbye message when the user chooses to quit the application

## Exercise Eleven: Advanced CodeRunner Exercises

Complete the methods in `ictgradschool.industry.controlflow.coderunner.AdvancedCodeRunner.java` using the concepts learned in the first three modules. The instructions are outlined in the class. You can test your answers by running the unit tests supplied in the test folder.

While these exercises are challenging, we encourage you to give them a go, especially if you've found the rest of this lab straightforward. Challenging yourself is a great way to improve!