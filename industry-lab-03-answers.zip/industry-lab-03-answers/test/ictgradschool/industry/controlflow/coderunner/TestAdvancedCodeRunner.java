package ictgradschool.industry.controlflow.coderunner;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Run this test to check your answers for the advanced CodeRunner exercises.
 * Do not modify this class.
 */
public class TestAdvancedCodeRunner {

    private AdvancedCodeRunner advancedCodeRunner;

    @BeforeEach
    public void setUp() {
        advancedCodeRunner = new AdvancedCodeRunner();
    }

    @Test
    public void testCountDigits() {
        assertEquals(1, advancedCodeRunner.countDigits(0));
        assertEquals(1, advancedCodeRunner.countDigits(1));
        assertEquals(2, advancedCodeRunner.countDigits(17));
        assertEquals(1, advancedCodeRunner.countDigits(-1));
        assertEquals(10, advancedCodeRunner.countDigits(1234567890));
        assertEquals(10, advancedCodeRunner.countDigits(-1234567890));
    }

    @Test
    public void testConvertIntToColTitle() {
        assertEquals("A", advancedCodeRunner.convertIntToColTitle(0));
        assertEquals("Z", advancedCodeRunner.convertIntToColTitle(25));
        assertEquals("AA", advancedCodeRunner.convertIntToColTitle(26));
        assertEquals("CI", advancedCodeRunner.convertIntToColTitle(86));
        assertEquals("AAA", advancedCodeRunner.convertIntToColTitle(702));
    }

    @Test
    public void testConvertIntToColTitleInvalid() {
        assertEquals("Input is invalid", advancedCodeRunner.convertIntToColTitle(-1));
        assertEquals("Input is invalid", advancedCodeRunner.convertIntToColTitle(-2));
    }

    @Test
    public void testIsIntegerPalindrome() {
        assertTrue(advancedCodeRunner.isIntPalindrome(101));
        assertTrue(advancedCodeRunner.isIntPalindrome(-101));
        assertTrue(advancedCodeRunner.isIntPalindrome(3));
        assertTrue(advancedCodeRunner.isIntPalindrome(88));
        assertTrue(advancedCodeRunner.isIntPalindrome(0));

        assertFalse(advancedCodeRunner.isIntPalindrome(2369));
        assertFalse(advancedCodeRunner.isIntPalindrome(2012));
        assertFalse(advancedCodeRunner.isIntPalindrome(1234));
    }

    @Test
    public void testPrintPrimeNumbers() {
        assertEquals("2 3 5 7 11 13 17 19", advancedCodeRunner.printPrimeNumbers(20));
        assertEquals("2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97 101", advancedCodeRunner.printPrimeNumbers(101));
        assertEquals("2 3 5 7", advancedCodeRunner.printPrimeNumbers(8));

        assertEquals("No prime number found", advancedCodeRunner.printPrimeNumbers(1));
        assertEquals("No prime number found", advancedCodeRunner.printPrimeNumbers(0));
        assertEquals("No prime number found", advancedCodeRunner.printPrimeNumbers(-1));
    }

    @Test
    public void testSimpleMultiplicationTable() {
        String result = advancedCodeRunner.simpleMultiplicationTable(1);
        if (result.contains(" \n")) {
            fail("Your output table has one or more extra spaces before the newline character. You can use the trim() function to remove additional spaces");
        }
        assertEquals("1", result);

        result = advancedCodeRunner.simpleMultiplicationTable(2);
        if (result.contains(" \n")) {
            fail("Your output table has one or more extra spaces before the newline character. You can use the trim() function to remove additional spaces");
        }
        assertEquals("1 2\n2 4", result);

        final String timesSeven = "1 2 3 4 5 6 7\n"
                + "2 4 6 8 10 12 14\n"
                + "3 6 9 12 15 18 21\n"
                + "4 8 12 16 20 24 28\n"
                + "5 10 15 20 25 30 35\n"
                + "6 12 18 24 30 36 42\n"
                + "7 14 21 28 35 42 49";

        result = advancedCodeRunner.simpleMultiplicationTable(7);
        if (result.contains(" \n")) {
            fail("Your output table has one or more extra spaces before the newline character. You can use the trim() function to remove additional spaces");
        }
        assertEquals(timesSeven, result);
    }

}
