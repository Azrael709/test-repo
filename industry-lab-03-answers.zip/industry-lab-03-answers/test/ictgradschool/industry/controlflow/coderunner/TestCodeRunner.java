package ictgradschool.industry.controlflow.coderunner;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Run this test to check your answers for the CodeRunner exercises.
 * Do not modify this class.
 */
public class TestCodeRunner {
    private CodeRunner codeRunner;

    @BeforeEach
    public void setUp() {
        codeRunner = new CodeRunner();
    }

    @Test
    public void testGetThreeLettersInCapital() {
        assertEquals("LLO", codeRunner.getThreeLettersInCapital("Hello World", 2));
        assertEquals("78", codeRunner.getThreeLettersInCapital("12345678", 6));
        assertEquals("", codeRunner.getThreeLettersInCapital("abcde", 5));
        assertEquals("ON", codeRunner.getThreeLettersInCapital("information", 9));
    }

    @Test
    public void testEnoughToBuyDrinks() {
        assertFalse(codeRunner.EnoughToBuyDrinks(0, 10, 5));
        assertTrue(codeRunner.EnoughToBuyDrinks(8, 1, 100));
        assertTrue(codeRunner.EnoughToBuyDrinks(0, 0, 10000));
    }

    @Test
    public void testImplies() {
        assertTrue(codeRunner.implies(true, true));
        assertTrue(codeRunner.implies(false, true));
        assertTrue(codeRunner.implies(false, false));

        assertFalse(codeRunner.implies(true, false));
    }

    @Test
    public void testCheckErrorInRange() {
        assertTrue(codeRunner.checkErrorInRange(25.586, 25.586, 0.0001));
        assertFalse(codeRunner.checkErrorInRange(1.23469, 1.22469, 0.0000005));
        assertTrue(codeRunner.checkErrorInRange(1.0, 1.000101, 0.1));
        assertFalse(codeRunner.checkErrorInRange(1.0, 1.0101, 0.001));
    }

    @Test
    public void testGenerateUsername() {
        assertEquals("tswi455", codeRunner.generateUsername("Taylor Swift"));
        assertEquals("twai437", codeRunner.generateUsername("Taika Waititi"));
        assertEquals("atur444", codeRunner.generateUsername("Alan Turing"));
        assertEquals("ghop430", codeRunner.generateUsername("Grace Hopper"));
    }
}