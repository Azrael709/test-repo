package ictgradschool.industry.oop.fruits;

public class Fruit {
    private String name;

    public Fruit(String name) {
        this.name = name;
    }

    public String getFruitName() {
        return this.name;
    }

    public void setFruitName(String name) {
        this.name = name;
    }
}
