package ictgradschool.industry.oop.sortingnumbers;

import ictgradschool.Keyboard;

/**
 * Write a program that prompts the user to enter a range – 2 integers representing a lower bound and an upper bound.
 * You should use Keyboard.readInput() for this. Then, convert these bounds from String to int using Integer.parseInt().
 * Your program should then use Math.random() to generate 3 random integers that lie between the range entered (inclusive),
 * and then use Math.min() to determine which of the random integers is the smallest.
 */
public class SortingNumbers {

    /**
     * TODO Your code here. You may also write additional methods if you like.
     */
    private void start() {
        System.out.print("Lower bound? ");
        int lower = Integer.parseInt(Keyboard.readInput());
        System.out.print("Upper bound? ");
        int upper = Integer.parseInt(Keyboard.readInput());
        int rand1 = genRandom(lower, upper);
        int rand2 = genRandom(lower, upper);
        int rand3 = genRandom(lower, upper);

        System.out.println("3 randomly generated numbers: " + rand1 + ", " + rand2 + " and " + rand3);
        System.out.println("Smallest number is " + Math.min(rand1, Math.min(rand2, rand3)));
    }

    private int genRandom(int lower, int upper) {
        return (int) (Math.random() * (upper - lower + 1)) + lower;
    }

    /**
     * Program entry point. Do not edit.
     */
    public static void main(String[] args) {

        SortingNumbers ex = new SortingNumbers();
        ex.start();

    }
}
