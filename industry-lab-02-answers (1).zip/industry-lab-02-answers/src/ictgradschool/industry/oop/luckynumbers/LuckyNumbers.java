package ictgradschool.industry.oop.luckynumbers;

/**
 * Write a program which generates 2 random integers between 25 and 30 (inclusive),
 * then uses Math.min() and Math.max() to display them in descending sequence.
 */
public class LuckyNumbers {
    /**
     * TODO Your code here. You may also write additional methods if you like.
     */
    private void start() {
        int rand1 = genRandom(25, 30);
        int rand2 = genRandom(25, 30);
        System.out.println("Your lucky numbers are " + Math.max(rand1, rand2) + " and " + Math.min(rand1, rand2));

    }

    private int genRandom(int lower, int upper) {
        return (int) (Math.random() * (upper - lower + 1)) + lower;
    }

    /**
     * Program entry point. Do not edit.
     */
    public static void main(String[] args) {

        LuckyNumbers ex = new LuckyNumbers();
        ex.start();

    }
}
