package ictgradschool.industry.oop.examples;

import ictgradschool.Keyboard;

/**
 * This example demonstrates the scope of variables and how parameters in
 * methods are in a different scope to variables outside of the method.
 * <p>
 * When the 'age' parameter within methods is modified, the age variable
 * outside of the method is not modified.
 * <p>
 * If you observe carefully, you will see that the only way that the age
 * variable within the 'start()' method is modified is when there is a
 * value returned from a method call and the returned value is assigned to
 * the age variable.
 */


public class ScopeOfVariables {

    public int returnIncrementedAge(int age) {
        System.out.println("Age within 'returnIncrementedAge()' is " + age);
        System.out.println("...incrementing age...");
        age++;
        System.out.println("Age within 'returnIncrementedAge()' is " + age);
        System.out.println("Press Enter to continue...");
        Keyboard.readInput();
        return age;
    }

    public void incrementAgeWithParameter(int age) {
        System.out.println("Age within 'incrementAgeWithParameter()' is " + age);
        System.out.println("...incrementing age...");
        age++;
        System.out.println("Age within 'incrementAgeWithParameter()' is " + age);
        System.out.println("Press Enter to continue...");
        Keyboard.readInput();
    }

    public void incrementAge() {
        int age = 30;
        System.out.println("Age within 'incrementAge()' is " + age);
        System.out.println("...incrementing age...");
        age++;
        System.out.println("Age within 'incrementAge()' is " + age);
        System.out.println("Press Enter to continue...");
        Keyboard.readInput();
    }

    public void start() {
        int age = 38;
        System.out.println("Age within 'start()' is: " + age);
        System.out.println("Press Enter to continue...");
        Keyboard.readInput();

        incrementAge();
        System.out.println("Age within 'start()' is: " + age);
        System.out.println("Age within 'start()' is not modified because of local scope");
        System.out.println("Press Enter to continue...");
        Keyboard.readInput();

        System.out.println("Age within 'start()' is: " + age);
        incrementAgeWithParameter(age);
        System.out.println("Age within 'start()' is: " + age);
        System.out.println("Age within 'start()' is not modified because the argument is passed to the method but the argument is local in scope");
        System.out.println("Press Enter to continue...");
        Keyboard.readInput();

        System.out.println("Age within 'start()' is: " + age);
        age = returnIncrementedAge(age);
        System.out.println("Age within 'start()' is: " + age);
        System.out.println("Age within 'start()' is MODIFIED because the modified age was returned from the method and assigned to the 'age' variable in 'start()'");

    }

    public static void main(String[] args) {
        ScopeOfVariables scopeOfVariables = new ScopeOfVariables();
        scopeOfVariables.start();
    }

}
