package ictgradschool.industry.oop.examples;

/**
 * This example contains three variations of basic methods
 * that add the sum of two integers.
 * <p>
 * All of the methods are called from within the start method.
 * <p>
 * It is similar to examples used in the lecture slides.
 * <p>
 * It shows variations on methods in which two methods add
 * numbers and output the result and another method adds numbers
 * and returns the result.
 * <p>
 * It is suggested that you observe the difference between the
 * method that adds the numbers and outputs the result and the
 * method that returns the result to be output back where the
 * method was called from.
 */

public class MethodsExample {

    public void addAndOutput(int numOne, int numTwo) {
        int sum = numOne + numTwo;
        System.out.println("The sum is: " + sum);
    }

    public int addAndReturn(int numOne, int numTwo) {
        int sum = numOne + numTwo;
        return sum;
    }

    public void addRandomInts() {
        int numOne = (int) Math.floor(Math.random() * 100);
        int numTwo = (int) Math.floor(Math.random() * 100);
        int sum = addAndReturn(numOne, numTwo);
        System.out.println("The sum of two random integers is: " + sum);
    }

    public void start() {
        // Calling a method that doesn't return anything:
        addAndOutput(3, 7);

        // Calling a method that returns a value:
        int sum = addAndReturn(3, 7);
        System.out.println("The sum is: " + sum);

        // Calling a method that has no parameters or return:
        addRandomInts();
    }

    public static void main(String[] args) {
        MethodsExample methodsExample = new MethodsExample();
        methodsExample.start();
    }

}
