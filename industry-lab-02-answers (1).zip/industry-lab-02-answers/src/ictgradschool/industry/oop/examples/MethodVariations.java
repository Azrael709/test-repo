package ictgradschool.industry.oop.examples;

/**
 * This example shows four method variations as outlined in the
 * lecture slides.
 * <p>
 * The variations are:
 * 1) No parameters and no returned value
 * 2) A parameter and no returned value
 * 3) A returned value and no parameter
 * 4) A parameter and a returned value
 * <p>
 * Have a look at the code carefully and try running the
 * code and tracing what happens. Make sure that you understand
 * what happens when a value is returned.
 */


public class MethodVariations {

    // Methods can have no arguments, and return nothing (void):
    public void sayHello() {
        System.out.println("Hello, World!");
    }

    // Methods can take one or more arguments, and return nothing:
    public void sayHelloTwo(String name) {
        System.out.println("Hello, " + name + "!");
    }

    // Methods can have no arguments, and return something:
    public String getHello() {
        return "Hello, World!";
    }

    // Mthods can take one or more arguments, and return something.
    public String getHelloTwo(String name) {
        return "Hello, " + name + "!";
    }

    public void start() {
        // Calling a method that takes no arguments and returns nothing:
        sayHello();
        // Calling a method that takes a name as an argument:
        sayHelloTwo("Alice");
        // Calling a method that returns a String and storing the String in a variable
        String hello = getHello();
        // Outputting the String returned by the method call on the line above
        System.out.println(hello);
        String helloTwo = getHelloTwo("Bob");
        System.out.println(helloTwo);

    }

    public static void main(String[] args) {
        MethodVariations methodVariations = new MethodVariations();
        methodVariations.start();
    }

}
