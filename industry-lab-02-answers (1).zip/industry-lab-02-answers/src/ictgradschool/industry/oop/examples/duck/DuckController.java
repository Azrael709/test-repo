package ictgradschool.industry.oop.examples.duck;

public class DuckController {

    public void start() {
        Duck duckOne = new Duck();
        Duck duckTwo = new Duck();

        duckOne.fly();
        duckTwo.fly();

        duckOne.walk();
        duckTwo.walk();
    }

    public static void main(String[] args) {
        DuckController duckController = new DuckController();
        duckController.start();
    }

}
