package ictgradschool.industry.oop.examples;

import ictgradschool.Keyboard;

/**
 * This example shows how code can be reused in a method through
 * turning specific parts of the code into paramters.
 * <p>
 * This example is based on an example shown in the lecture slide
 * in which the prompt to the used is turned into a parameter in
 * the method. The steps of prompting the user and reading keyboard
 * input can then be contained in the method to avoid repetition.
 */

public class CodeReuseExample {

    // By parameterising the prompts, we can reuse the common statements with more flexibility
    private int getUserInt(String prompt) {
        System.out.print(prompt + ": ");
        String userStr = Keyboard.readInput();
        int userIn = Integer.parseInt(userStr);
        return userIn;
    }

    public void start() {

        System.out.print("Enter row: ");
        String userStr = Keyboard.readInput();
        int rowA = Integer.parseInt(userStr);

        System.out.print("Enter column: ");
        userStr = Keyboard.readInput();
        int colA = Integer.parseInt(userStr);

        // We can call the methods below and supply the different prompts
        int rowB = getUserInt("Enter row");
        int colB = getUserInt("Enter column");

    }

    public static void main(String[] args) {
        CodeReuseExample codeReuseExample = new CodeReuseExample();
        codeReuseExample.start();
    }

}
