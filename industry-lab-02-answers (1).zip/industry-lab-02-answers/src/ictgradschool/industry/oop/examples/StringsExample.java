package ictgradschool.industry.oop.examples;

/**
 * This example shows various String operations.
 * <p>
 * It also contains a large amount of System.out... statements.
 * <p>
 * It is suggested that you run the code and observe what is
 * output by each of the System.out... statements.
 */

public class StringsExample {

    public void start() {
        String greeting = new String("Hello World");
        System.out.println("greeting = " + greeting);
        int greetingLength = greeting.length();
        System.out.println("greeting.length() = " + greetingLength);
        char c1 = greeting.charAt(0);
        System.out.println("greeting.charAt(0) = " + c1);
        int position = greeting.indexOf('d');
        System.out.println("greeting.indexOf('d') = " + position);
        String subStr = greeting.substring(8);
        System.out.println("greeting.substring(8) = " + subStr);
        String subStr2 = greeting.substring(0, 2);
        System.out.println("greeting.substring(0, 2) = " + subStr2);
        String greetingInUpperCase = greeting.toUpperCase();
        System.out.println("greeting.toUpperCase() = " + greetingInUpperCase);
        String greetingInLowerCase = greeting.toLowerCase();
        System.out.println("greeting.toLowerCase() = " + greetingInLowerCase);

    }

    public static void main(String[] args) {
        StringsExample stringsExample = new StringsExample();
        stringsExample.start();
    }

}
