package ictgradschool.industry.oop.examples.flexyduck;

/**
 * This is a FlexyDuck class that can be used to create a FlexyDuck object.
 * This is a modification of the duck class used in the lecture slides.
 * <p>
 * <p>
 * Ducks have instance variables for their number of feet and number of wings.
 * <p>
 * Ducks have methods to fly and to walk.
 * <p>
 * The constructor 'public FlexyDuck()...' is used to create the new FlexyDuck object and
 * set the number of feet and wings to any desired number.
 */
public class FlexyDuck {

    private int numFeet;
    private int numWings;

    // Creates a duck with whatever number of wings and feet is defined when the object is created
    public FlexyDuck(int feet, int wings) {
        numFeet = feet;
        numWings = wings;
    }

    public void fly() {
        System.out.println("The duck flies using its " + numWings + " wings!");
    }

    public void walk() {
        System.out.println("The duck walks on its own " + numFeet + " feet!");
    }

}
