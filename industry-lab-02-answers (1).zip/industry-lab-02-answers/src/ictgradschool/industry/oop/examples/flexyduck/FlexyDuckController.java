package ictgradschool.industry.oop.examples.flexyduck;

public class FlexyDuckController {

    public void start() {
        FlexyDuck flexyDuckOne = new FlexyDuck(2, 2);
        FlexyDuck flexyDuckTwo = new FlexyDuck(3, 1);

        flexyDuckOne.fly();
        flexyDuckTwo.fly();

        flexyDuckOne.walk();
        flexyDuckTwo.walk();
    }

    public static void main(String[] args) {
        FlexyDuckController flexyDuckController = new FlexyDuckController();
        flexyDuckController.start();
    }

}
