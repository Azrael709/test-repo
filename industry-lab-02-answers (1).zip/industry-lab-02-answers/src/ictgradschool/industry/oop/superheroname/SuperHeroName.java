package ictgradschool.industry.oop.superheroname;

import ictgradschool.Keyboard;

/**
 * Complete the contents of the method below so that the user can enter their favourite colour and animal
 * and the output will tell them their superhero name.
 * <p>
 * The superhero name should capitalise the first letter of each of the inputs and make sure all other letters
 * are lowercase.
 * <p>
 * Example:
 * If the user inputs 'pink' and 'wombat', the output should be 'Your superhero name is The Pink Wombat'.
 * If the user input 'PINK' and 'WOMBAT', the output should be 'Your superhero name is The Pink Wombat'.
 * <p>
 * This task will require the use of string methods, it is suggested that you revise the lecture slides related
 * to string methods, look at the examples related to string methods and use online reference material as needed.
 */

public class SuperHeroName {

    public String getSuperHeroName(String favouriteColour, String favouriteAnimal) {
        // TODO: Complete the contents of this method so that it returns the complete superhero name; make sure to appropriately capitalise it
        String tempColour = favouriteColour.substring(0, 1).toUpperCase() + favouriteColour.substring(1).toLowerCase();
        String tempAnimal = favouriteAnimal.substring(0, 1).toUpperCase() + favouriteAnimal.substring(1).toLowerCase();
        return tempColour + " " + tempAnimal;
    }

    public void start() {
        System.out.println("What is your favourite colour?");
        String favouriteColour = Keyboard.readInput();

        System.out.println("What is your favourite animal?");
        String favouriteAnimal = Keyboard.readInput();

        String superHeroName = getSuperHeroName(favouriteColour, favouriteAnimal);
        System.out.println("Your superhero name is " + superHeroName);

    }

    public static void main(String[] args) {
        SuperHeroName superHeroName = new SuperHeroName();
        superHeroName.start();
    }

}
