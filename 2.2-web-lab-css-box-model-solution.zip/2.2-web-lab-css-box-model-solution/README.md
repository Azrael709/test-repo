# Web Lab &ndash; CSS Positioning

In this lab, we continue our CSS coverage - this time, looking at CSS positioning and other methods of moving elements on a page.

## Obtaining the code

Now that you've obtained a copy of this repository through GitHub Classroom's invite, you have your own private version of this repository (i.e. the one you're looking at now)! To clone this repository onto your machine, click the green `Code` button, make sure `HTTPS` is selected, then click the `copy` button to the right of the web URL to copy its value. Then, clone onto your local machine from a terminal, using the `git clone` command.

If this is the first time you've ever cloned a repository on the current machine, you may be asked to enter your GitHub credentials. The "sign in with your browser" option should work just fine. You may need to enter your GitHub username and password, and / or authorize "git credential manager" to access your account. Perform these steps if asked.

Now, you should have a clone of your repository on your local machine, ready to develop!

Remember to commit and push your work regularly for backup purposes.

## Exercise One - Basic Layout With Box Model

This exercise is designed to give you an opportunity to practise laying out content using padding, margin and other CSS properties.

You have been provided some place holder content and basic CSS code; when the page initially loads it should look something like this:

![](spec/ex-01-incomplete-page.PNG)

Notice that before the appropriate CSS properties are added that all text and images are against the left side of the screen and paragraphs stretch across the full width of the screen.

### Task:

Your goal will be to use a range of CSS properties to change the way that elements are laid out so that it looks something like this:

![](spec/ex-01-completed-page.PNG)

You should examine the contents of the HTML and CSS file provided to you and familiarise yourself with the code.

There are some `div` elements within the HTML page with `id` or `class` attributes that have associated CSS selectors that can be used to apply CSS properties to major blocks of the page like the `nav` and main `container` . Make sure you look carefully at the structure of the HTML and the default CSS selectors provided to you as you will be making use of these to complete the task.

You should also think carefully about what CSS selectors you can use; you may create new CSS selectors if required.

You do not have to make your page look exactly like the image above; you should experiment and view the page in your web browser to make sure that the spacing of elements is suitable to view in your browser.

The most important thing is that the finished page looks something like the image above; feel free to experiment with various CSS properties and observe the results; the following general requirements and hints can be used as a guide if you are stuck:

- All headings (`h1`& `h2` elements) should be centered and the text within them should be center aligned
- There should be suitable padding within `h1` and `h2` elements so that the text is not running to the edge of the element
- The `h2` elements should be centered within their surrounding div and the text inside the `h2` elements should be centred
- Text in paragraph elements should be left aligned, but there should be padding within the paragraph element to stop the text from running to the edge of the element
- The `h1` and `nav` div elements should extend across the full width of the screen
- There should be no white space in between these elements

  - You will likely find that by default there is white space above and below the `h1` element due to some default properties of elements; you will be able to override default properties with CSS code you write in the CSS file
- The `container` div element that contains the `h2` , `paragraph` and `image` elements should be narrower than the screen and have blank white margin space on the left and right as can be seen in the image above; the blank margins either side of the `container` div should take up about 20% of the screen each with the `container` div being centred in the middle

  - **Hint**: if you are having difficulty centering the `container` div, investigate the `margin: auto;` property and look up information about how to use it
- The image elements should be centred

  - **Hint**: there are various methods for centering image elements; image elements are inline elements by default which means they are laid out in much the same way as text characters would be within their parent element; one option for centering images is using the `display: block;` property in CSS to force image elements to be block level elements and then use the `margin: auto;` property to centre them within their parent element
- The anchor elements/links within the `nav` div should be right-aligned with space in between each link as can be seen in the image above
- Padding, margin and other properties should be used where appropriate to make all elements position themselves similar to the image above; make sure to pay attention to how the `h2` and `paragraph` elements position themselves within the parent element (the `container` div); there should be space between the edge of the  `h2` and `paragraph` elements and the edge of the `container` div
- **Note**: remember that sometimes modifying the margin of a child element will achieve a similar result to modifying the padding of its parent element; there are some advantages to either approach depending on the context so make sure to consider carefully what option is best in any given context
- When finished, you can remove the `1px solid black` border property that is added to all elements by deleting or commenting out the appropriate lines of CSS

When finished, try resizing your browser window and/or zooming in and out in order to check that elements still display appropriately on varying screen sizes. If you have mainly used padding and margin properties, you should find that most page content displays fairly well as the window or zoom level changes. There are some properties that can cause issues when pages resize; for example, adding fixed widths to any elements can cause them to overflow outside of containing elements.

# Exercise 2 - Delightful Ducks

In this task you will structure and style a range of content and images related to ducks.

This will involve applying a range of HTML and CSS skills that you have learnt in this course.

When you have finished, your page should look something like this:

![img](./spec/ducks-task.PNG)

## Task 1 - Structuring HTML Content (10 marks)

For this task, you will structure the HTML content in the page.

You will see in the question-one.html file that you have been provided with some of the very basic HTML tags and some text content within the `body` tags.

You should structure the HTML content according to the following criteria:

- The main heading should be an h1 element
- The subheadings should be h2 elements with `id` added so that the `nav` links can link to each section
- The links within the `nav` section should be anchor elements that will link to the information about the different types of ducks based on the `id` on the `h1` elements
- The table should have two columns and use `th` elements in the header row and `td` elements within the other rows
- The main text content of the duck information sections should be in paragraphs with `p` elements
- You should also use `div` elements to group all major sections of the page like the header, nav, main content and the sections for the table and duck information within the main content
  - You should add appropriate `id` and/or `class` attributes to elements as needed
  - Observe the screenshot above carefully to get an idea of how the main sections of the page will be grouped

When all of your HTML tags have been added, your page should look something like this:

![img](./spec/html-content.PNG)

## Task 2 - Basic CSS styling 

For this task, you will add a range of CSS style settings to your page.

This task does involve examining the screenshots provided carefully and working out what CSS settings you can use to replicate the style in the screenshots as closely as possible. Your page does not need to look exactly the same as the screenshots, but you should aim to replicate the style of the page shown in the screenshots as closely as possible.

For this task, you should do the following:

- Create a CSS file and link it to your HTML file
- Add any `div` elements you think you may need within your HTML file
- Add any `class` or `id` attributes you need to your HTML elements
- Add all required CSS properties to replicate the style shown in the screens shots

Make sure to observe the screenshots carefully and read the extra notes about style below relating to:

- Color
- Font
- Border
- Drop shadow
- ...and other style properties

Note: there will be some CSS properties required that will not have been covered specifically in course content; you may need to use reference information to achieve some effects. It is suggested that you look up reference information for `border-radius` and `drop-shadow` as these CSS properties can be used for effects like rounded corners on borders and the shadow seen on the edges of divs.

When this task is finished, it should look something like this:

![img](./spec/full-no-images.PNG)

Make sure to refer back to this screenshot as needed to check how the whole page should look. Your page may vary slightly depending on your screen size and level of zoom; however, you should aim to replicate the general style of the screenshot above as closely as possible. Make sure that your page looks ok when the screen resizes slightly. It is not a requirement to make it display on a very narrow phone sized screen; however, make sure to resize your screen at some times to check that it will display ok on most general laptop and desktop computers.

### Colors for page:

This is the color palette that you should use for the page:

![img](./spec/colors.PNG)

Your goal is to replicate the general style of the page observed in the screenshots provided. You should be able to see from the screenshots which of the colors from the color palette above to use for different elements in the page. You may wish to make CSS variable names for each of the colors so that you can use them throughout your CSS.

In addition to the color palette above, the color of the box shadow used in the screenshots is `#929292`.

### Font:

You have been provided with a `.ttf` file within the `assets -> fonts` directory. This font is for a font family called `Ephesis` .You should add this to your page through `@font-face` in your CSS; make sure to look up reference information if you're not sure how to do that. All text on the page should use the `Ephesis` font family.

### General styling of header and nav:

The header and nav should be styled to look something like this:

![img](./spec/header-nav.PNG)

## Task 3 - Adding images

In this section you will finish the page by adding all images to the page.

All of the required images are included in the `assets -> images` directory. You should be able to work out which images go where by comparing the screenshot below with the images in the directory. In the case of the images for the duck information sections, the file names of the images should indicate which duck they relate to.

Note that the duck sprite images in the header at the left and right of the main title should appear either side of the title text with each duck facing the title. Make sure you consider carefully how you can most easily make the images appear next to the title; the nesting of elements will affect whether they display inline with text. You will need to research a way to invert one of the ducks to face the correct direction.

When this task is finished, it should look similar to the screenshot below:

![img](./spec/ducks-task-2.PNG)

## Optional bonus task:

Within the images directoy, there is a `Spinning_Duck.gif` image. As an optional bonus task you may wish to include this in the page somehow. Get creative and do something interesting with the spinning duck gif. This is an entirely optional task that is not worth any extra marks, but you may wish to do this if you finish early.
